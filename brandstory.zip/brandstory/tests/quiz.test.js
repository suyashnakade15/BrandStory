// Run: node tests/quiz.test.js
const assert=require('assert'),d=require('../js/data.js'),{buildQuiz}=d;global.COMPANIES=d.COMPANIES;require('../js/data2.js');const {COMPANIES}=d;
for(const [id,c] of Object.entries(COMPANIES)){if(!c.ready)continue;check(id,c.quiz,c)}
function check(id,rows,c){
assert.strictEqual(rows.length,20,'20 questions');
rows.forEach(r=>{assert.strictEqual(r.length,5,'1 question + 4 answers: '+r[0]);assert.strictEqual(new Set(r.slice(1)).size,4,'unique answers: '+r[0])});
assert.strictEqual(new Set(rows.map(r=>r[0])).size,20,'unique questions');
const qOrder=new Set(),aOrder=new Set(),pos=[0,0,0,0];
for(let n=0;n<300;n++){const qs=buildQuiz(rows);assert.strictEqual(qs.length,20);
 qOrder.add(qs.map(q=>q.q).join('|'));
 qs.forEach(q=>{const row=rows.find(r=>r[0]===q.q);assert.strictEqual(q.opts.filter(o=>o.ok).length,1);
  assert.strictEqual(q.opts.find(o=>o.ok).t,row[1],'correct answer preserved');
  assert.deepStrictEqual(q.opts.map(o=>o.t).sort(),row.slice(1).sort());pos[q.opts.findIndex(o=>o.ok)]++});
 aOrder.add(qs[0].opts.map(o=>o.t).join('|'))}
assert(qOrder.size>250,'questions are shuffled');assert(aOrder.size>1,'answers are shuffled');
assert(pos.every(p=>p>20*300*0.18),'correct answer lands in every position: '+pos);
console.log(id,'OK. positions:',pos.join(', '),'| story slides:',c.story.length)}
