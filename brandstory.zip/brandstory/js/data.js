/* BrandStory content + quiz logic. Quiz row: [question, CORRECT answer, wrong, wrong, wrong]. Order is randomised at runtime. */
const COMPANIES = {
apple:{name:"Apple",icon:"🍎",blurb:"From a family garage to one of the world's best-known brands.",ready:true,
 intro:"Apple began in 1976 when two friends who loved electronics decided to build computers that ordinary people could use. Today it is known for the Mac, iPhone, iPad and more.",
 founders:["Steve Jobs — the visionary who obsessed over simple, beautiful products.","Steve Wozniak — the engineer who designed the first Apple computers.","Ronald Wayne — a co-founder who sold his small share within weeks for $800."],
 struggles:["Early money was tight: the founders sold personal belongings to fund the first computers.","In 1985 Jobs left Apple after a power struggle, and the company lost direction for years.","By 1997 Apple was close to bankruptcy before Jobs returned and simplified its products."],
 innovations:["Apple II: one of the first successful mass-produced personal computers.","Macintosh: brought the mouse and on-screen icons to everyday users.","iPod, iPhone and iPad: made music, phones and tablets simple and personal."],
 timeline:[["1976","Apple is founded and the Apple I is built."],["1984","The Macintosh is introduced."],["1997","Jobs returns; the 'Think Different' campaign launches."],["2001","The iPod arrives."],["2007","The iPhone changes phones forever."],["2018","Apple becomes the first US company worth $1 trillion."]],
 lessons:["Start small — big companies often begin in a garage.","Great partnerships combine different skills.","Failure is feedback: Jobs came back stronger after leaving.","Simplicity is a design superpower."],
 story:[["🏠","A garage in California","In 1976, two friends, Steve Jobs and Steve Wozniak, worked in a family garage. Wozniak built the circuits; Jobs saw that everyday people would want them."],["💸","Selling to fund a dream","To raise money for parts, they sold things they owned. It wasn't much, but it was enough to build their first batch of computers."],["🖥️","The computer for everyone","The Apple II made computers friendly. Schools and families began to bring them home."],["🚪","A hard turn","In 1985 Jobs left the company he started. Apple struggled, while Jobs kept learning by building new things."],["🔄","The comeback","Jobs returned in 1997 and focused Apple on a few excellent products. 'Think Different' reminded the world what Apple stood for."],["📱","Pocket-sized magic","The iPod and then the iPhone put music and the internet in everyone's hands."],["🌟","The big lesson","Apple shows that curiosity, teamwork and never giving up can turn a small idea into something huge."]],
 quiz:[
["In which year was Apple founded?","1976","1984","1969","1998"],
["Who were Apple's three founders?","Steve Jobs, Steve Wozniak, Ronald Wayne","Steve Jobs, Bill Gates, Paul Allen","Tim Cook, Steve Jobs, Jony Ive","Steve Wozniak, Larry Page, Ronald Wayne"],
["Where was Apple started?","In a family garage in California","In a Tokyo laboratory","In a New York bank","In a London university"],
["Who designed the hardware of the first Apple computers?","Steve Wozniak","Tim Cook","Ronald Wayne","John Sculley"],
["How much did Ronald Wayne sell his Apple share for?","$800","$8 million","$80","$1 billion"],
["Which Apple computer, launched in 1977, became a big early success?","Apple II","iMac","MacBook Air","Apple Watch"],
["Which product brought the mouse and icons to everyday users in 1984?","Macintosh","iPod","iPad","Apple TV"],
["In which year did Steve Jobs leave Apple the first time?","1985","1976","2001","2011"],
["Which animation studio did Jobs buy and help grow after leaving Apple?","Pixar","DreamWorks","Ghibli","Aardman"],
["Which company did Apple buy in 1997, bringing Jobs back?","NeXT","Atari","Netscape","Sun"],
["Which colourful 1998 computer helped save Apple?","iMac","Apple I","Newton","Lisa"],
["Which Apple slogan promoted the 1997 comeback campaign?","Think Different","Just Do It","Connect People","Impossible Is Nothing"],
["Which device first promised '1,000 songs in your pocket'?","iPod","iPad","iPhone","Apple Watch"],
["In which year was the iPhone introduced?","2007","1999","2014","2003"],
["What opened in 2008 so people could download apps for iPhone?","The App Store","iTunes Radio","Apple Arcade","iCloud"],
["Which tablet did Apple launch in 2010?","iPad","iMac","iPod nano","HomePod"],
["Who became Apple's CEO in 2011?","Tim Cook","Jony Ive","Steve Wozniak","Phil Schiller"],
["In 2018, Apple became the first US company worth about how much?","$1 trillion","$1 million","$10 billion","$100 billion"],
["Jobs studied calligraphy, which inspired what on the Mac?","Beautiful fonts and typography","The mouse","The charger","The camera"],
["Apple's headquarters, Apple Park, is in which city?","Cupertino","Seattle","Austin","Boston"]]},
tata:{name:"Tata",icon:"🏭",blurb:"A trusted Indian group that grew across steel, cars, tea and more.",ready:false},
microsoft:{name:"Microsoft",icon:"🪟",blurb:"Two friends, a big idea: software on every desk.",ready:false}
};
const shuffle=a=>{a=a.slice();for(let i=a.length-1;i>0;i--){const j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}return a};
const buildQuiz=rows=>shuffle(rows).map(r=>({q:r[0],opts:shuffle(r.slice(1).map((t,i)=>({t,ok:i===0})))}));
if(typeof module!=="undefined")module.exports={COMPANIES,shuffle,buildQuiz};
