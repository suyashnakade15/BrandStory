const app=document.getElementById('app');
const load=()=>{try{return JSON.parse(localStorage.getItem('bs')||'{}')}catch(e){return{}}};
const save=o=>{try{localStorage.setItem('bs',JSON.stringify({...load(),...o}))}catch(e){}};
const esc=s=>String(s).replace(/[&<>"]/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;'}[c]));
const li=a=>a.map(x=>`<li>${esc(x)}</li>`).join('');
function toggleNav(){const n=document.getElementById('nav'),o=n.classList.toggle('open');document.querySelector('.burger').setAttribute('aria-expanded',o)}
let S=null;
const views={
home(){const L=Object.entries(COMPANIES).filter(([,c])=>c.ready),qn=L.reduce((n,[,c])=>n+c.quiz.length,0);
const strip=L.map(([,c])=>`<span>${c.icon} ${c.name}</span>`).join('');
app.innerHTML=`<section class="hero"><span class="eyebrow">✦ Learn • Play • Discover</span><h1>Brand<span class="shine">Story</span></h1><div class="rule"></div><p class="tag">Every Brand Has a Story</p>
<p>Discover how famous companies began, how founders beat tough challenges, and how tiny ideas became global brands. Read, play, and unlock 3D animated stories.</p>
<div class="row"><a class="btn" href="#/library">Explore Companies →</a><a class="btn ghost" href="#/company/apple">Start with Apple</a></div>
<div class="stats"><div><b>${L.length}</b><span>Companies</span></div><div><b>${qn}</b><span>Quiz questions</span></div><div><b>${L.length}</b><span>Animated stories</span></div></div></section>
<div class="marq" aria-hidden="true"><div>${strip}${strip}${strip}${strip}</div></div>
<section class="wrap"><div class="sec" style="margin-top:0"><h2>How it works</h2><div class="grid steps"><div class="card"><span class="num">1</span><h3>📖 Learn</h3><p>Read the founders' story, struggles, milestones and lessons.</p></div><div class="card"><span class="num">2</span><h3>🎮 Play</h3><p>Take a 20-question quiz with instant feedback. Earn XP and badges.</p></div><div class="card"><span class="num">3</span><h3>🔓 Discover</h3><p>Unlock an illustrated 3D story of the founder journey.</p></div></div></div>
<div class="sec"><h2>Featured companies</h2><div class="grid">${L.slice(0,3).map(([id,c])=>`<a class="card feat" href="#/company/${id}"><div class="logo-big">${c.icon}</div><h3>${c.name}</h3><p>${c.blurb}</p><span class="pill g">Read story + quiz →</span></a>`).join('')}</div></div>
<div class="cta card"><h2>Ready to find your favourite story?</h2><p>Six brands are waiting. Which founder's journey will inspire you?</p><a class="btn" href="#/library">Browse all companies</a></div>
<div class="sec"><h2>Coming next</h2><ul class="plan"><li>Phase 3: student accounts, leaderboards, daily challenges</li><li>Phase 4: admin dashboard and AI learning helper</li></ul></div></section>`},
library(){const d=load();app.innerHTML=`<section class="wrap"><h1>Company Library</h1><p style="color:var(--mute)">Pick a company to read its story.</p><div class="grid">`+Object.entries(COMPANIES).map(([id,c])=>c.ready?
`<a class="card" href="#/company/${id}"><div class="logo-big">${c.icon}</div><h3>${c.name}</h3><p>${c.blurb}</p><span class="pill g">${d['best_'+id]!=null?'Best score '+d['best_'+id]+'/20':'20-question quiz'}</span></a>`:
`<div class="card soon"><div class="logo-big">${c.icon}</div><h3>${c.name}</h3><p>${c.blurb}</p><span class="pill">Coming in Phase 2</span></div>`).join('')+`</div></section>`},
company(id){const c=COMPANIES[id];if(!c||!c.ready)return location.hash='#/library';
app.innerHTML=`<section class="wrap"><a href="#/library">← All companies</a><h1 style="margin-top:12px">${c.icon} ${c.name}</h1><p>${esc(c.intro)}</p>
<div class="sec"><h2>Founders</h2><ul>${li(c.founders)}</ul></div><div class="sec"><h2>Early struggles</h2><ul>${li(c.struggles)}</ul></div><div class="sec"><h2>Innovations</h2><ul>${li(c.innovations)}</ul></div>
<div class="sec"><h2>Milestones</h2><ul class="tl">${c.timeline.map(t=>`<li><b>${t[0]}</b> — ${esc(t[1])}</li>`).join('')}</ul></div>
<div class="sec"><h2>Lessons for students</h2><ul>${li(c.lessons)}</ul></div>
<div class="card"><h3>Ready to test yourself?</h3><p>Answer 20 questions. Finish to unlock the animated founder story.</p><a class="btn" href="#/quiz/${id}">Start the quiz</a></div></section>`},
quiz(id){const c=COMPANIES[id];if(!c||!c.ready)return location.hash='#/library';S={id,qs:buildQuiz(c.quiz),i:0,score:0};ask()},
results(){if(!S||S.i<S.qs.length)return location.hash='#/library';const c=COMPANIES[S.id],n=S.score,t=S.qs.length;
const msg=n>=18?'Brilliant! You are a brand expert.':n>=12?'Great work! Almost there.':n>=6?'Good start — read the story again and retry.':'Every expert starts here. Try again!';
app.innerHTML=`<section class="wrap" style="text-align:center"><h1>${c.name} quiz complete</h1><div class="score">${n}<small>/${t}</small></div><p>${msg}</p><p>+${n*10} XP earned</p><div>${badges(n)}</div>
<div class="row" style="justify-content:center"><a class="btn" href="#/story/${S.id}">🔓 Unlock animated story</a><a class="btn ghost" href="#/quiz/${S.id}">Retake quiz</a><a class="btn ghost" href="#/library">Library</a></div></section>`},
story(id){const c=COMPANIES[id];if(!c||!c.ready)return location.hash='#/library';
if(!load()['done_'+id]){app.innerHTML=`<section class="wrap" style="text-align:center"><h1>🔒 Story locked</h1><p>Finish the ${c.name} quiz to unlock this story.</p><a class="btn" href="#/quiz/${id}">Take the quiz</a></section>`;return}
let k=0;const sl=c.story;const draw=()=>{const s=sl[k];app.innerHTML=`<section class="wrap"><a href="#/company/${id}">← ${c.name}</a><div class="stage"><div class="slide"><div class="art">${s[0]}</div><h2>${esc(s[1])}</h2><p>${esc(s[2])}</p></div></div>
<div class="dots">${sl.map((_,j)=>`<i class="${j<=k?'on':''}"></i>`).join('')}</div><div class="row" style="justify-content:center"><button class="btn ghost" id="pv" ${k?'':'disabled'}>Back</button><button class="btn" id="nx">${k<sl.length-1?'Next':'Finish'}</button></div></section>`;
document.getElementById('pv').onclick=()=>{k--;draw()};document.getElementById('nx').onclick=()=>{k<sl.length-1?(k++,draw()):location.hash='#/library'}};draw()}
};
function badges(n){return[[1,'🌱 Curious Learner'],[10,'⭐ Rising Star'],[15,'🏅 Brand Explorer'],[20,'👑 Perfect Score']].filter(x=>n>=x[0]).map(x=>`<span class="badge">${x[1]}</span>`).join('')}
function ask(){const q=S.qs[S.i],t=S.qs.length;
app.innerHTML=`<section class="wrap"><div style="display:flex;justify-content:space-between;color:var(--mute)"><span>Question ${S.i+1} of ${t}</span><span>Score ${S.score}</span></div>
<div class="bar" role="progressbar" aria-valuemin="0" aria-valuemax="${t}" aria-valuenow="${S.i}"><i style="width:${S.i/t*100}%"></i></div><h2 class="q">${esc(q.q)}</h2>
<div id="opts">${q.opts.map((o,j)=>`<button class="opt" data-j="${j}">${esc(o.t)}</button>`).join('')}</div><div class="fb" id="fb" aria-live="polite"></div><button class="btn" id="nx" style="display:none"></button></section>`;
document.querySelectorAll('.opt').forEach(b=>b.onclick=()=>{const o=q.opts[b.dataset.j];
document.querySelectorAll('.opt').forEach((x,j)=>{x.disabled=true;if(q.opts[j].ok)x.classList.add('ok')});
const fb=document.getElementById('fb');if(o.ok){S.score++;fb.className='fb ok';fb.textContent='✓ Correct!'}else{b.classList.add('bad');fb.className='fb bad';fb.textContent='✗ Not quite — the correct answer is highlighted.'}
document.querySelector('.bar i').style.width=(S.i+1)/t*100+'%';
const nx=document.getElementById('nx');nx.style.display='inline-block';nx.textContent=S.i<t-1?'Next question':'See results';nx.focus();
nx.onclick=()=>{S.i++;if(S.i<t)ask();else finish()}})}
function finish(){const d=load(),k='best_'+S.id;save({xp:(d.xp||0)+S.score*10,['done_'+S.id]:true,[k]:Math.max(d[k]||0,S.score)});location.hash='#/results'}
function showXP(){document.getElementById('xp').textContent=(load().xp||0)+' XP'}
function route(){const[p,id]=location.hash.replace('#/','').split('/');(views[p]||views.home)(id);window.scrollTo(0,0);document.getElementById('nav').classList.remove('open');showXP()}
addEventListener('hashchange',route);route();
