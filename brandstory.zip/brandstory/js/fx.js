/* 3D effects: ambient rings, hero cube, tilt on cards. Loaded after app.js. */
(()=>{const app=document.getElementById('app'),calm=matchMedia('(prefers-reduced-motion:reduce)').matches;
const bg=document.createElement('div');bg.className='bg3d';bg.setAttribute('aria-hidden','true');bg.innerHTML=[...Array(7)].map((_,i)=>`<i style="--i:${i}"></i>`).join('');document.body.prepend(bg);
function enhance(){const h=app.querySelector('.hero');
 if(h&&!h.querySelector('.cube')){const ic=['🍎','🏭','🪟','🔎','📦','⚡'];h.insertAdjacentHTML('beforeend',`<div class="scene" aria-hidden="true"><div class="cube">${['front','back','right','left','top','bottom'].map((f,i)=>`<b class="${f}">${ic[i]}</b>`).join('')}</div></div>`)}
 if(calm)return;
 app.querySelectorAll('.card,.stage').forEach(el=>{if(el.dataset.t)return;el.dataset.t=1;
  el.addEventListener('pointermove',e=>{const r=el.getBoundingClientRect(),x=(e.clientX-r.left)/r.width-.5,y=(e.clientY-r.top)/r.height-.5;el.style.transform=`perspective(800px) rotateY(${x*14}deg) rotateX(${-y*14}deg) translateZ(8px)`});
  el.addEventListener('pointerleave',()=>{el.style.transform=''})})}
new MutationObserver(enhance).observe(app,{childList:true});enhance();
if(!calm)addEventListener('pointermove',e=>{const s=document.body.style;s.setProperty('--mx',(e.clientX/innerWidth-.5).toFixed(2));s.setProperty('--my',(e.clientY/innerHeight-.5).toFixed(2))})})();
