# BrandStory — Every Brand Has a Story
Managed by Suyash Nakade. Independent educational platform; not affiliated with or endorsed by featured companies.

## Run locally
Option A: double-click `index.html` (no install needed).
Option B: `python3 -m http.server 8000` in this folder, then open http://localhost:8000
Test quiz logic: `node tests/quiz.test.js`

## Publish online (free, gets a public URL)
- Netlify: go to app.netlify.com/drop, drag this folder in → instant https URL.
- GitHub Pages: push to a repo → Settings → Pages → deploy from `main` / root → https://USERNAME.github.io/REPO
- Cloudflare Pages / Vercel: import the repo; no build command, output directory `/`.

## Structure
index.html · css/style.css · js/data.js (content + shuffle logic) · js/app.js (routing, quiz, results, story) · tests/quiz.test.js · js/data2.js (Phase 2 companies) · js/fx.js + css/3d.css (3D effects)
Add a company: add an entry in `COMPANIES` (js/data.js) with `ready:true`, story, 20 quiz rows.
Progress (XP, best scores, unlocked stories) is saved in the browser's localStorage.
